
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<div class="container" style="margin-top: 90px; width: 500px;">
    <h4> <img src="images/thumbs_down.png">Você não possui cadastro</h4>
	
 	<div style="text-align: right; margin-right: 260px;">
		<a href="index.php" class="btn btn-sm btn-secondary" >Voltar</a>
	</div>
    </div>