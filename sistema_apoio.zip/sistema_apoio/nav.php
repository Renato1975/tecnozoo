    <nav class="navbar navbar-primary bg-primary flex-md-nowrap p-0">
      <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="menu.php" style="color:#fff" 
      ><i class="fab fa-angellist" ></i>&nbsp;Sis Apoio</a>
       <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap" style="margin-right: 50px;" >
          <p style="color: #fff"><u> Oi <?php echo $dados['nome']; ?>!&nbsp;<i class="far fa-smile-wink"></i></u></p>
          <center>
          <a class="nav-link" href="logout.php" style="color: #fff"><i class="fas fa-sign-out-alt">&nbsp;</i>Sair</a>
          </center>
        </li>
      </ul>
    </nav>